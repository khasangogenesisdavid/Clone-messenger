-- ============================================================
--  CLONE MESSENGER — SUPABASE DATABASE SCHEMA
--  Run this in your Supabase project:
--  Dashboard → SQL Editor → New Query → Paste → Run
-- ============================================================

-- USERS TABLE
create table if not exists public.users (
  id              uuid primary key references auth.users(id) on delete cascade,
  display_name    text not null default 'Clone User',
  email           text,
  phone           text,
  hashed_phone    text,          -- SHA-256 hash for contact discovery
  avatar_url      text,
  public_key      text,          -- X25519 public key for E2EE
  is_online       boolean default false,
  last_seen       timestamptz default now(),
  created_at      timestamptz default now()
);

-- CHATS TABLE (1-on-1 conversations)
create table if not exists public.chats (
  id                  uuid primary key default gen_random_uuid(),
  participant_ids     uuid[] not null,
  last_message        text,
  last_message_at     timestamptz,
  last_message_type   text default 'text',
  created_at          timestamptz default now()
);

-- MESSAGES TABLE
create table if not exists public.messages (
  id                      uuid primary key default gen_random_uuid(),
  chat_id                 uuid references public.chats(id) on delete cascade,
  sender_id               uuid references public.users(id) on delete set null,
  type                    text not null default 'text',
  -- Encrypted content
  content                 text,          -- encrypted ciphertext
  nonce                   text,          -- encryption nonce
  -- Media
  media_url               text,          -- path in Supabase Storage
  encrypted_media_key     text,          -- symmetric key encrypted with recipient pubkey
  media_mime_type         text,
  -- View-once
  view_once_viewed        boolean default false,
  view_once_viewed_at     timestamptz,
  created_at              timestamptz default now()
);

-- ── INDEXES ──────────────────────────────────────────────────
create index if not exists idx_messages_chat_id     on public.messages(chat_id);
create index if not exists idx_messages_created_at  on public.messages(created_at desc);
create index if not exists idx_chats_participants   on public.chats using gin(participant_ids);
create index if not exists idx_users_hashed_phone   on public.users(hashed_phone);

-- ── ROW LEVEL SECURITY ────────────────────────────────────────
alter table public.users    enable row level security;
alter table public.chats    enable row level security;
alter table public.messages enable row level security;

-- Users: anyone authenticated can read profiles; only owner can update
create policy "users_select" on public.users for select using (auth.role() = 'authenticated');
create policy "users_insert" on public.users for insert with check (auth.uid() = id);
create policy "users_update" on public.users for update using (auth.uid() = id);

-- Chats: only participants can read/write
create policy "chats_select" on public.chats for select using (auth.uid() = any(participant_ids));
create policy "chats_insert" on public.chats for insert with check (auth.uid() = any(participant_ids));
create policy "chats_update" on public.chats for update using (auth.uid() = any(participant_ids));

-- Messages: only chat participants can read; only sender can insert
create policy "messages_select" on public.messages for select
  using (
    exists (
      select 1 from public.chats
      where id = messages.chat_id
      and auth.uid() = any(participant_ids)
    )
  );

create policy "messages_insert" on public.messages for insert
  with check (
    auth.uid() = sender_id
    and exists (
      select 1 from public.chats
      where id = messages.chat_id
      and auth.uid() = any(participant_ids)
    )
  );

-- Only allow view_once update (no deletes from client)
create policy "messages_update_viewonce" on public.messages for update
  using (auth.role() = 'authenticated')
  with check (view_once_viewed = true);

-- ── REALTIME ─────────────────────────────────────────────────
-- Enable realtime for messages and chats
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.chats;

-- ── STORAGE BUCKETS ──────────────────────────────────────────
-- Run these in the Supabase Storage section or via SQL:
insert into storage.buckets (id, name, public) values ('view-once-media', 'view-once-media', false)
  on conflict do nothing;

insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true)
  on conflict do nothing;

-- Storage policies
create policy "view_once_insert" on storage.objects for insert
  with check (bucket_id = 'view-once-media' and auth.role() = 'authenticated');

create policy "view_once_select" on storage.objects for select
  using (bucket_id = 'view-once-media' and auth.role() = 'authenticated');

create policy "avatars_public_read" on storage.objects for select
  using (bucket_id = 'avatars');

create policy "avatars_auth_insert" on storage.objects for insert
  with check (bucket_id = 'avatars' and auth.role() = 'authenticated');
