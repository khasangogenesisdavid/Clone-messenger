// src/hooks/useMessages.ts
import { useState, useEffect, useCallback } from 'react';
import { getMessages, subscribeToMessages, decryptMessages, sendMessage } from '../services/chatService';
import { useAuth } from './useAuth';
import type { Message } from '../types';

export function useMessages(chatId: string) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!chatId || !user) return;

    // Load initial messages
    getMessages(chatId).then(async (msgs) => {
      const decrypted = await decryptMessages(msgs, user.id);
      setMessages(decrypted);
      setLoading(false);
    });

    // Subscribe to real-time updates
    const channel = subscribeToMessages(chatId, async (newMsg) => {
      const [decrypted] = await decryptMessages([newMsg], user.id);
      setMessages((prev) => [...prev, decrypted]);
    });

    return () => { channel.unsubscribe(); };
  }, [chatId, user]);

  const send = useCallback(
    async (text: string, recipientPublicKey: string) => {
      if (!user) return;
      await sendMessage(chatId, user.id, text, recipientPublicKey);
    },
    [chatId, user]
  );

  return { messages, loading, sendMessage: send };
}
