// src/hooks/useTheme.ts
import { useThemeStore } from '../stores/themeStore';
import { BasePurplePalette } from '../theme/colors';

export function useTheme() {
  const { theme, setTheme, resetTheme } = useThemeStore();

  // Derived glass colors from current theme primary
  const glassColors = {
    glassBg:     `${theme.primary}26`,    // 15% opacity
    glassBorder: `${theme.glow}40`,       // 25% opacity
    glowShadow:  `${theme.primary}66`,    // 40% opacity
  };

  return {
    theme,
    setTheme,
    resetTheme,
    colors: BasePurplePalette,
    glass: glassColors,
  };
}
