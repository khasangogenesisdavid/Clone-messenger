// src/hooks/useAuth.ts
import { useEffect } from 'react';
import { supabase } from '../config/supabase';
import { useAuthStore } from '../stores/authStore';
import type { User } from '../types';

export function useAuth() {
  const { user, session, loading, setUser, setSession, setLoading, clear } = useAuthStore();

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session?.user) {
        fetchUserProfile(data.session.user.id);
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session?.user) {
        fetchUserProfile(session.user.id);
      } else {
        clear();
        setLoading(false);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  async function fetchUserProfile(userId: string) {
    setLoading(true);
    const { data } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    setUser(data as User);
    setLoading(false);
  }

  return { user, session, loading, isAuthenticated: !!session };
}
