// src/types/index.ts

export interface User {
  id: string;
  display_name: string;
  email?: string;
  phone?: string;
  avatar_url?: string;
  public_key?: string;
  hashed_phone?: string;
  created_at: string;
  last_seen?: string;
  is_online?: boolean;
}

export interface Chat {
  id: string;
  participant_ids: string[];
  last_message?: string;
  last_message_at?: string;
  last_message_type?: MessageType;
  created_at: string;
  // Populated client-side
  other_user?: User;
  unread_count?: number;
}

export type MessageType =
  | 'text'
  | 'image'
  | 'video'
  | 'view_once_image'
  | 'view_once_video'
  | 'audio'
  | 'system';

export interface Message {
  id: string;
  chat_id: string;
  sender_id: string;
  type: MessageType;
  content?: string;               // encrypted text
  nonce?: string;                 // encryption nonce
  media_url?: string;             // encrypted media storage path
  encrypted_media_key?: string;   // symmetric key encrypted with recipient pubkey
  media_mime_type?: string;
  view_once_viewed?: boolean;
  view_once_viewed_at?: string;
  created_at: string;
  // Client-side only (decrypted)
  decrypted_content?: string;
  sender?: User;
}

export interface AppTheme {
  primary: string;
  primaryLight: string;
  primaryDark: string;
  glow: string;
}

export interface AuthState {
  user: User | null;
  session: any | null;
  loading: boolean;
}
