// src/config/constants.ts

export const APP_NAME = 'Clone';
export const APP_VERSION = '1.0.0';

// Message types
export const MESSAGE_TYPES = {
  TEXT: 'text',
  IMAGE: 'image',
  VIDEO: 'video',
  VIEW_ONCE_IMAGE: 'view_once_image',
  VIEW_ONCE_VIDEO: 'view_once_video',
  AUDIO: 'audio',
  SYSTEM: 'system',
} as const;

// View-once auto-dismiss timer (milliseconds)
export const VIEW_ONCE_DISPLAY_MS = 10_000;

// Max file sizes
export const MAX_IMAGE_SIZE_MB = 10;
export const MAX_VIDEO_SIZE_MB = 50;

// Pagination
export const MESSAGES_PER_PAGE = 30;
export const CONTACTS_PER_PAGE = 50;
