// src/config/supabase.ts
// ─────────────────────────────────────────────────────────────────
//  SETUP INSTRUCTIONS:
//  1. Go to https://supabase.com and create a FREE account
//  2. Create a new project (choose any region close to you)
//  3. Go to Project Settings → API
//  4. Copy your "Project URL" and "anon public" key
//  5. Replace the two values below
// ─────────────────────────────────────────────────────────────────

import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SUPABASE_URL = 'https://YOUR_PROJECT_ID.supabase.co'; // 👈 REPLACE THIS
const SUPABASE_ANON_KEY = 'YOUR_ANON_KEY_HERE';              // 👈 REPLACE THIS

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export default supabase;
