// src/stores/authStore.ts
import { create } from 'zustand';
import { supabase } from '../config/supabase';
import type { User } from '../types';

interface AuthStore {
  user: User | null;
  session: any | null;
  loading: boolean;
  setUser: (user: User | null) => void;
  setSession: (session: any) => void;
  setLoading: (v: boolean) => void;
  clear: () => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  session: null,
  loading: true,
  setUser: (user) => set({ user }),
  setSession: (session) => set({ session }),
  setLoading: (loading) => set({ loading }),
  clear: () => set({ user: null, session: null }),
}));
