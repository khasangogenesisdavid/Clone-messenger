// src/stores/themeStore.ts
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { DEFAULT_THEME, type AppThemeColors } from '../theme/colors';

interface ThemeStore {
  theme: AppThemeColors;
  setTheme: (theme: AppThemeColors) => void;
  updateTheme: (partial: Partial<AppThemeColors>) => void;
  resetTheme: () => void;
}

export const useThemeStore = create<ThemeStore>()(
  persist(
    (set) => ({
      theme: DEFAULT_THEME,
      setTheme: (theme) => set({ theme }),
      updateTheme: (partial) => set((s) => ({ theme: { ...s.theme, ...partial } })),
      resetTheme: () => set({ theme: DEFAULT_THEME }),
    }),
    {
      name: 'clone-theme-v1',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
