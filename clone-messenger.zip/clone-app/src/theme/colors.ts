// src/theme/colors.ts

export const BasePurplePalette = {
  primary:       '#7B2FBE',
  primaryLight:  '#A855F7',
  primaryDark:   '#4C1D95',
  glow:          '#C084FC',

  glassBg:       'rgba(123, 47, 190, 0.15)',
  glassBorder:   'rgba(200, 150, 255, 0.25)',
  glassSheen:    'rgba(255, 255, 255, 0.06)',

  background:    '#0D0118',
  surface:       '#1A0533',
  surfaceLight:  '#2D1055',

  textPrimary:   '#F3E8FF',
  textSecondary: '#C4B5D8',
  textMuted:     '#7C6B8E',

  success:       '#34D399',
  error:         '#F87171',
  warning:       '#FBBF24',
  info:          '#60A5FA',

  white:         '#FFFFFF',
  black:         '#000000',
  transparent:   'transparent',
};

export const DEFAULT_THEME: AppThemeColors = {
  primary:      BasePurplePalette.primary,
  primaryLight: BasePurplePalette.primaryLight,
  primaryDark:  BasePurplePalette.primaryDark,
  glow:         BasePurplePalette.glow,
};

export interface AppThemeColors {
  primary: string;
  primaryLight: string;
  primaryDark: string;
  glow: string;
}

// Preset theme options users can pick from
export const THEME_PRESETS: { name: string; theme: AppThemeColors }[] = [
  {
    name: 'Royal Purple',
    theme: { primary: '#7B2FBE', primaryLight: '#A855F7', primaryDark: '#4C1D95', glow: '#C084FC' },
  },
  {
    name: 'Ocean Blue',
    theme: { primary: '#1D4ED8', primaryLight: '#3B82F6', primaryDark: '#1E3A8A', glow: '#93C5FD' },
  },
  {
    name: 'Rose Gold',
    theme: { primary: '#BE185D', primaryLight: '#EC4899', primaryDark: '#831843', glow: '#F9A8D4' },
  },
  {
    name: 'Emerald',
    theme: { primary: '#065F46', primaryLight: '#10B981', primaryDark: '#022C22', glow: '#6EE7B7' },
  },
  {
    name: 'Sunset Orange',
    theme: { primary: '#C2410C', primaryLight: '#F97316', primaryDark: '#7C2D12', glow: '#FED7AA' },
  },
  {
    name: 'Midnight',
    theme: { primary: '#374151', primaryLight: '#6B7280', primaryDark: '#111827', glow: '#D1D5DB' },
  },
];
