// src/theme/typography.ts
import { StyleSheet } from 'react-native';
import { BasePurplePalette as C } from './colors';

export const typography = StyleSheet.create({
  // Display
  displayLarge:  { fontSize: 36, fontWeight: '800', color: C.textPrimary, letterSpacing: -0.5 },
  displayMedium: { fontSize: 28, fontWeight: '700', color: C.textPrimary, letterSpacing: -0.3 },

  // Headings
  h1: { fontSize: 24, fontWeight: '700', color: C.textPrimary },
  h2: { fontSize: 20, fontWeight: '600', color: C.textPrimary },
  h3: { fontSize: 17, fontWeight: '600', color: C.textPrimary },

  // Body
  bodyLarge:  { fontSize: 16, fontWeight: '400', color: C.textPrimary, lineHeight: 24 },
  bodyMedium: { fontSize: 14, fontWeight: '400', color: C.textSecondary, lineHeight: 20 },
  bodySmall:  { fontSize: 12, fontWeight: '400', color: C.textMuted, lineHeight: 18 },

  // UI labels
  label:      { fontSize: 13, fontWeight: '500', color: C.textSecondary },
  labelSmall: { fontSize: 11, fontWeight: '500', color: C.textMuted, letterSpacing: 0.4 },
  caption:    { fontSize: 11, fontWeight: '400', color: C.textMuted },

  // Messages
  messageText:    { fontSize: 15, fontWeight: '400', color: C.textPrimary, lineHeight: 22 },
  messageTime:    { fontSize: 10, fontWeight: '400', color: C.textMuted },
  messageSender:  { fontSize: 12, fontWeight: '600', color: C.primaryLight },
});
