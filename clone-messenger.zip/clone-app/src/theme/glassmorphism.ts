// src/theme/glassmorphism.ts
import { StyleSheet } from 'react-native';

export const glass = StyleSheet.create({
  // Main card container
  card: {
    backgroundColor: 'rgba(123, 47, 190, 0.15)',
    borderWidth: 1,
    borderColor: 'rgba(200, 150, 255, 0.25)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  cardElevated: {
    backgroundColor: 'rgba(123, 47, 190, 0.22)',
    borderWidth: 1,
    borderColor: 'rgba(200, 150, 255, 0.35)',
    borderRadius: 20,
    shadowColor: '#7B2FBE',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 12,
  },
  // Message bubbles
  messageSent: {
    backgroundColor: 'rgba(139, 92, 246, 0.35)',
    borderWidth: 1,
    borderColor: 'rgba(196, 181, 255, 0.3)',
    borderRadius: 18,
    borderBottomRightRadius: 4,
  },
  messageReceived: {
    backgroundColor: 'rgba(255, 255, 255, 0.07)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
    borderRadius: 18,
    borderBottomLeftRadius: 4,
  },
  // Input fields
  input: {
    backgroundColor: 'rgba(123, 47, 190, 0.12)',
    borderWidth: 1,
    borderColor: 'rgba(200, 150, 255, 0.2)',
    borderRadius: 14,
  },
  inputFocused: {
    backgroundColor: 'rgba(123, 47, 190, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(168, 85, 247, 0.6)',
    borderRadius: 14,
  },
  // Bottom bar / header bar
  bar: {
    backgroundColor: 'rgba(13, 1, 24, 0.75)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(200, 150, 255, 0.1)',
  },
  // Avatar ring
  avatarRing: {
    borderWidth: 2,
    borderColor: 'rgba(192, 132, 252, 0.6)',
    borderRadius: 999,
  },
  // Pill badge
  badge: {
    backgroundColor: 'rgba(139, 92, 246, 0.4)',
    borderWidth: 1,
    borderColor: 'rgba(196, 181, 255, 0.3)',
    borderRadius: 999,
  },
});
