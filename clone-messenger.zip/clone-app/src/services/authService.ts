// src/services/authService.ts
import { supabase } from '../config/supabase';
import * as SecureStore from 'expo-secure-store';
import { cryptoService } from './cryptoService';
import type { User } from '../types';

// ─── Google OAuth ─────────────────────────────────────────────────────────────

/**
 * Sign in with Google.
 * Opens a browser popup → redirects back to the app with a session.
 */
export async function signInWithGoogle() {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: 'clone://auth/callback',
      scopes: 'email profile',
    },
  });
  if (error) throw error;
  return data;
}

// ─── Email / Password ─────────────────────────────────────────────────────────

export async function signUpWithEmail(email: string, password: string, displayName: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { display_name: displayName } },
  });
  if (error) throw error;
  if (data.user) await postAuthSetup(data.user.id, { email, displayName });
  return data;
}

export async function signInWithEmail(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

// ─── Phone / OTP ──────────────────────────────────────────────────────────────

/**
 * Step 1: Send OTP to phone number (must be E.164 format: +256712345678)
 */
export async function sendPhoneOTP(phone: string) {
  const e164 = enforceE164(phone);
  const { data, error } = await supabase.auth.signInWithOtp({ phone: e164 });
  if (error) throw error;
  return data;
}

/**
 * Step 2: Verify OTP code the user received via SMS
 */
export async function verifyPhoneOTP(phone: string, token: string) {
  const e164 = enforceE164(phone);
  const { data, error } = await supabase.auth.verifyOtp({
    phone: e164,
    token,
    type: 'sms',
  });
  if (error) throw error;
  if (data.user) await postAuthSetup(data.user.id, { phone: e164 });
  return data;
}

// ─── Sign Out ─────────────────────────────────────────────────────────────────

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

// ─── Get Current Session ──────────────────────────────────────────────────────

export async function getSession() {
  const { data } = await supabase.auth.getSession();
  return data.session;
}

export async function getCurrentUser(): Promise<User | null> {
  const { data } = await supabase.auth.getUser();
  if (!data.user) return null;

  const { data: profile } = await supabase
    .from('users')
    .select('*')
    .eq('id', data.user.id)
    .single();

  return profile;
}

// ─── Post-Auth Setup ──────────────────────────────────────────────────────────

/**
 * Called once after any successful sign-in / sign-up.
 * - Generates E2EE key pair if first time on this device
 * - Upserts user profile in Supabase
 */
async function postAuthSetup(
  userId: string,
  info: { email?: string; phone?: string; displayName?: string }
) {
  // Check if key pair already exists for this device
  const existingKey = await SecureStore.getItemAsync(`privkey_${userId}`);

  let publicKey = '';

  if (!existingKey) {
    const { publicKey: pk, privateKey: sk } = await cryptoService.generateKeyPair();
    publicKey = pk;
    // Private key stays on device only — never sent anywhere
    await SecureStore.setItemAsync(`privkey_${userId}`, sk);
  } else {
    // Re-derive public key from stored private key
    // (In production: store pubkey separately in SecureStore too)
    const { publicKey: pk } = await cryptoService.generateKeyPair();
    publicKey = pk;
  }

  // Hash phone for privacy-safe contact discovery
  const hashedPhone = info.phone
    ? await cryptoService.hashPhone(info.phone)
    : null;

  // Upsert user profile (creates on first sign-up, updates on subsequent logins)
  await supabase.from('users').upsert({
    id: userId,
    display_name: info.displayName ?? 'Clone User',
    email: info.email ?? null,
    phone: info.phone ?? null,
    hashed_phone: hashedPhone,
    public_key: publicKey,
    last_seen: new Date().toISOString(),
    is_online: true,
  });
}

// ─── Helper ───────────────────────────────────────────────────────────────────

function enforceE164(phone: string): string {
  if (!phone.startsWith('+')) {
    throw new Error('Phone number must start with country code, e.g. +256712345678');
  }
  return phone;
}
