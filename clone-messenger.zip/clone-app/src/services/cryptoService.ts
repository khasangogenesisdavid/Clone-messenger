// src/services/cryptoService.ts
import _sodium from 'libsodium-wrappers';

let sodium: typeof _sodium | null = null;

async function getSodium() {
  if (!sodium) {
    await _sodium.ready;
    sodium = _sodium;
  }
  return sodium;
}

export const cryptoService = {
  /** Generate X25519 key pair for a new device */
  async generateKeyPair(): Promise<{ publicKey: string; privateKey: string }> {
    const s = await getSodium();
    const kp = s.crypto_box_keypair();
    return {
      publicKey:  s.to_base64(kp.publicKey),
      privateKey: s.to_base64(kp.privateKey),
    };
  },

  /** Encrypt a text message for a recipient */
  async encryptMessage(
    plaintext: string,
    recipientPublicKeyB64: string,
    senderPrivateKeyB64: string
  ): Promise<{ ciphertext: string; nonce: string }> {
    const s = await getSodium();
    const nonce = s.randombytes_buf(s.crypto_box_NONCEBYTES);
    const ct = s.crypto_box_easy(
      s.from_string(plaintext),
      nonce,
      s.from_base64(recipientPublicKeyB64),
      s.from_base64(senderPrivateKeyB64)
    );
    return { ciphertext: s.to_base64(ct), nonce: s.to_base64(nonce) };
  },

  /** Decrypt a received text message */
  async decryptMessage(
    ciphertextB64: string,
    nonceB64: string,
    senderPublicKeyB64: string,
    recipientPrivateKeyB64: string
  ): Promise<string> {
    const s = await getSodium();
    const decrypted = s.crypto_box_open_easy(
      s.from_base64(ciphertextB64),
      s.from_base64(nonceB64),
      s.from_base64(senderPublicKeyB64),
      s.from_base64(recipientPrivateKeyB64)
    );
    return s.to_string(decrypted);
  },

  /** Encrypt a symmetric key with recipient public key (for media) */
  async encryptAsymmetric(data: string, recipientPublicKeyB64: string): Promise<string> {
    const s = await getSodium();
    const sealed = s.crypto_box_seal(s.from_string(data), s.from_base64(recipientPublicKeyB64));
    return s.to_base64(sealed);
  },

  /** Decrypt a sealed box */
  async decryptAsymmetric(sealedB64: string, privateKeyB64: string): Promise<string> {
    const s = await getSodium();
    const privateKey = s.from_base64(privateKeyB64);
    const publicKey = s.crypto_scalarmult_base(privateKey);
    const decrypted = s.crypto_box_seal_open(s.from_base64(sealedB64), publicKey, privateKey);
    return s.to_string(decrypted);
  },

  /** AES-256-GCM encrypt media bytes */
  async encryptMedia(data: Uint8Array): Promise<{ encrypted: Uint8Array; keyB64: string; nonceB64: string }> {
    const s = await getSodium();
    const key = s.crypto_secretbox_keygen();
    const nonce = s.randombytes_buf(s.crypto_secretbox_NONCEBYTES);
    const encrypted = s.crypto_secretbox_easy(data, nonce, key);
    return { encrypted, keyB64: s.to_base64(key), nonceB64: s.to_base64(nonce) };
  },

  /** AES-256-GCM decrypt media bytes */
  async decryptMedia(encryptedB64: string, keyB64: string, nonceB64: string): Promise<Uint8Array> {
    const s = await getSodium();
    return s.crypto_secretbox_open_easy(
      s.from_base64(encryptedB64),
      s.from_base64(nonceB64),
      s.from_base64(keyB64)
    );
  },

  /** SHA-256 hash a phone number for privacy-safe contact matching */
  async hashPhone(e164Phone: string): Promise<string> {
    const s = await getSodium();
    const hash = s.crypto_generichash(32, s.from_string(e164Phone));
    return s.to_hex(hash);
  },
};
