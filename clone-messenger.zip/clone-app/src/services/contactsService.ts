// src/services/contactsService.ts
import * as Contacts from 'expo-contacts';
import { supabase } from '../config/supabase';
import { cryptoService } from './cryptoService';
import type { User } from '../types';

/**
 * Sync device contacts and discover which ones are on Clone.
 * Privacy model: phone numbers are hashed before leaving the device.
 */
export async function discoverContactsOnClone(currentUserId: string): Promise<User[]> {
  // 1. Request contacts permission
  const { status } = await Contacts.requestPermissionsAsync();
  if (status !== 'granted') {
    throw new Error('Contacts permission denied');
  }

  // 2. Load all contacts with phone numbers
  const { data } = await Contacts.getContactsAsync({
    fields: [Contacts.Fields.PhoneNumbers],
  });

  if (!data || data.length === 0) return [];

  // 3. Normalise to E.164 and hash each number
  const hashes: string[] = [];
  for (const contact of data) {
    if (!contact.phoneNumbers) continue;
    for (const phoneObj of contact.phoneNumbers) {
      const e164 = normaliseToE164(phoneObj.number ?? '');
      if (e164) {
        const hash = await cryptoService.hashPhone(e164);
        hashes.push(hash);
      }
    }
  }

  if (hashes.length === 0) return [];

  // 4. Query Supabase for matching hashed phones (in batches of 50)
  const BATCH = 50;
  const matches: User[] = [];

  for (let i = 0; i < hashes.length; i += BATCH) {
    const batch = hashes.slice(i, i + BATCH);
    const { data: users } = await supabase
      .from('users')
      .select('id, display_name, avatar_url, public_key')
      .in('hashed_phone', batch)
      .neq('id', currentUserId); // exclude self

    if (users) matches.push(...users);
  }

  return matches;
}

/** Search users by display name or email */
export async function searchUsers(query: string, currentUserId: string): Promise<User[]> {
  if (query.trim().length < 2) return [];

  const { data, error } = await supabase
    .from('users')
    .select('id, display_name, avatar_url, email')
    .or(`display_name.ilike.%${query}%,email.ilike.%${query}%`)
    .neq('id', currentUserId)
    .limit(20);

  if (error) throw error;
  return data ?? [];
}

// ─── Helper ───────────────────────────────────────────────────────────────────

/**
 * Best-effort normalisation to E.164.
 * Handles common formats: 0712345678, +256712345678, 256712345678
 * Assumes Uganda (+256) as default country — adjust for your market.
 */
function normaliseToE164(raw: string): string | null {
  const digits = raw.replace(/\D/g, '');
  if (digits.length === 0) return null;

  // Already has country code
  if (raw.startsWith('+')) return raw.replace(/\s/g, '');

  // Uganda local: starts with 0 + 9 digits = 10 digits
  if (digits.length === 10 && digits.startsWith('0')) {
    return `+256${digits.slice(1)}`;
  }
  // International without +
  if (digits.length >= 11) return `+${digits}`;

  return null;
}
