// src/services/chatService.ts
import { supabase } from '../config/supabase';
import * as SecureStore from 'expo-secure-store';
import { cryptoService } from './cryptoService';
import type { Chat, Message } from '../types';

// ─── Chats ────────────────────────────────────────────────────────────────────

/** Get or create a 1-on-1 chat between two users */
export async function getOrCreateChat(currentUserId: string, otherUserId: string): Promise<Chat> {
  // Check if chat already exists
  const { data: existing } = await supabase
    .from('chats')
    .select('*')
    .contains('participant_ids', [currentUserId, otherUserId])
    .single();

  if (existing) return existing;

  // Create new chat
  const { data, error } = await supabase
    .from('chats')
    .insert({ participant_ids: [currentUserId, otherUserId] })
    .select()
    .single();

  if (error) throw error;
  return data;
}

/** Fetch all chats for the current user */
export async function getUserChats(userId: string): Promise<Chat[]> {
  const { data, error } = await supabase
    .from('chats')
    .select(`
      *,
      messages (
        content, type, created_at, sender_id
      )
    `)
    .contains('participant_ids', [userId])
    .order('last_message_at', { ascending: false });

  if (error) throw error;
  return data ?? [];
}

// ─── Messages ─────────────────────────────────────────────────────────────────

/** Send an encrypted text message */
export async function sendMessage(
  chatId: string,
  senderId: string,
  plaintext: string,
  recipientPublicKey: string
): Promise<Message> {
  // Get sender's private key from device
  const senderPrivKey = await SecureStore.getItemAsync(`privkey_${senderId}`);
  if (!senderPrivKey) throw new Error('Sender key not found on device');

  // Encrypt the message
  const { ciphertext, nonce } = await cryptoService.encryptMessage(
    plaintext,
    recipientPublicKey,
    senderPrivKey
  );

  const { data, error } = await supabase
    .from('messages')
    .insert({
      chat_id: chatId,
      sender_id: senderId,
      type: 'text',
      content: ciphertext,
      nonce,
    })
    .select()
    .single();

  if (error) throw error;

  // Update chat's last_message_at
  await supabase
    .from('chats')
    .update({
      last_message: '[Encrypted message]',
      last_message_at: new Date().toISOString(),
      last_message_type: 'text',
    })
    .eq('id', chatId);

  return data;
}

/** Fetch messages for a chat (paginated) */
export async function getMessages(
  chatId: string,
  page = 0,
  pageSize = 30
): Promise<Message[]> {
  const { data, error } = await supabase
    .from('messages')
    .select('*, sender:users(id, display_name, avatar_url, public_key)')
    .eq('chat_id', chatId)
    .order('created_at', { ascending: false })
    .range(page * pageSize, (page + 1) * pageSize - 1);

  if (error) throw error;
  return (data ?? []).reverse();
}

/** Decrypt a batch of messages using stored private key */
export async function decryptMessages(
  messages: Message[],
  currentUserId: string
): Promise<Message[]> {
  const privateKey = await SecureStore.getItemAsync(`privkey_${currentUserId}`);
  if (!privateKey) return messages;

  return Promise.all(
    messages.map(async (msg) => {
      if (msg.type !== 'text' || !msg.content || !msg.nonce || !msg.sender?.public_key) {
        return msg;
      }
      try {
        const decrypted = await cryptoService.decryptMessage(
          msg.content,
          msg.nonce,
          msg.sender.public_key,
          privateKey
        );
        return { ...msg, decrypted_content: decrypted };
      } catch {
        return { ...msg, decrypted_content: '[Unable to decrypt]' };
      }
    })
  );
}

/** Subscribe to real-time new messages in a chat */
export function subscribeToMessages(
  chatId: string,
  onNewMessage: (message: Message) => void
) {
  return supabase
    .channel(`chat:${chatId}`)
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'messages', filter: `chat_id=eq.${chatId}` },
      (payload) => onNewMessage(payload.new as Message)
    )
    .subscribe();
}

/** Mark a View-Once message as viewed (server-side) */
export async function markViewOnceViewed(messageId: string): Promise<void> {
  const { error } = await supabase
    .from('messages')
    .update({
      view_once_viewed: true,
      view_once_viewed_at: new Date().toISOString(),
    })
    .eq('id', messageId)
    .eq('view_once_viewed', false); // atomic: only update if not already viewed

  if (error) throw error;
}
