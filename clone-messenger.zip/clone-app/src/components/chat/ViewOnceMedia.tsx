// src/components/chat/ViewOnceMedia.tsx
import React, { useState, useCallback } from 'react';
import { View, Text, Pressable, StyleSheet, ActivityIndicator, Alert, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as SecureStore from 'expo-secure-store';
import { supabase } from '../../config/supabase';
import { cryptoService } from '../../services/cryptoService';
import { markViewOnceViewed } from '../../services/chatService';
import { useAuth } from '../../hooks/useAuth';
import { VIEW_ONCE_DISPLAY_MS } from '../../config/constants';
import type { Message } from '../../types';

interface ViewOnceMediaProps {
  message: Message;
  isMine: boolean;
}

type ViewState = 'unopened' | 'loading' | 'viewing' | 'expired';

export function ViewOnceMedia({ message, isMine }: ViewOnceMediaProps) {
  const { user } = useAuth();
  const [viewState, setViewState] = useState<ViewState>(
    message.view_once_viewed ? 'expired' : 'unopened'
  );
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(10);

  const handleOpen = useCallback(() => {
    if (viewState !== 'unopened' || isMine) return;

    Alert.alert(
      '👁 View Once',
      'This photo can only be viewed once. It will disappear after 10 seconds.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'View Now', style: 'destructive', onPress: openMedia },
      ]
    );
  }, [viewState, isMine]);

  const openMedia = async () => {
    setViewState('loading');
    try {
      // 1. Atomically mark as viewed in Supabase (prevents double-view)
      await markViewOnceViewed(message.id);

      // 2. Get a short-lived signed URL from Supabase Storage
      const { data: signedData } = await supabase.storage
        .from('view-once-media')
        .createSignedUrl(message.media_url!, 60); // 60 second URL

      if (!signedData?.signedUrl) throw new Error('Could not get media URL');

      // 3. Fetch encrypted bytes
      const response = await fetch(signedData.signedUrl);
      const arrayBuffer = await response.arrayBuffer();
      const encryptedBytes = new Uint8Array(arrayBuffer);

      // 4. Get this device's private key
      const privateKey = await SecureStore.getItemAsync(`privkey_${user!.id}`);
      if (!privateKey) throw new Error('Device key missing');

      // 5. Decrypt the symmetric media key
      const symmetricKey = await cryptoService.decryptAsymmetric(
        message.encrypted_media_key!,
        privateKey
      );
      const [keyB64, nonceB64] = symmetricKey.split(':');

      // 6. Decrypt the media bytes in memory
      const decryptedBytes = await cryptoService.decryptMedia(
        Buffer.from(encryptedBytes).toString('base64'),
        keyB64,
        nonceB64
      );

      // 7. Convert to displayable URI (base64 data URI — stays in memory only)
      const base64 = Buffer.from(decryptedBytes).toString('base64');
      const mimeType = message.media_mime_type ?? 'image/jpeg';
      setImageUri(`data:${mimeType};base64,${base64}`);
      setViewState('viewing');

      // 8. Countdown and auto-expire
      let secs = 10;
      const interval = setInterval(() => {
        secs--;
        setCountdown(secs);
        if (secs <= 0) {
          clearInterval(interval);
          setImageUri(null); // clear from memory
          setViewState('expired');
        }
      }, 1000);

    } catch (err) {
      console.error('ViewOnce error:', err);
      setViewState('unopened');
      Alert.alert('Error', 'Could not open media. It may have already been viewed.');
    }
  };

  // ── Render ─────────────────────────────────────────────────────────────────

  if (viewState === 'expired') {
    return (
      <View style={[styles.container, isMine ? styles.sent : styles.received, styles.expired]}>
        <Ionicons name="eye-off-outline" size={18} color="rgba(200,160,255,0.4)" />
        <Text style={styles.expiredText}>{isMine ? 'Photo sent · viewed' : 'Photo opened'}</Text>
      </View>
    );
  }

  if (viewState === 'loading') {
    return (
      <View style={[styles.container, styles.received]}>
        <ActivityIndicator color="#A855F7" size="small" />
        <Text style={styles.loadingText}>Decrypting…</Text>
      </View>
    );
  }

  if (viewState === 'viewing' && imageUri) {
    return (
      <View style={styles.viewingWrapper}>
        <Image source={{ uri: imageUri }} style={styles.media} resizeMode="cover" />
        <View style={styles.countdownBadge}>
          <Ionicons name="timer-outline" size={13} color="#fff" />
          <Text style={styles.countdownText}>{countdown}s</Text>
        </View>
      </View>
    );
  }

  // Default: unopened
  return (
    <Pressable
      style={[styles.container, isMine ? styles.sent : styles.received]}
      onPress={handleOpen}
    >
      <View style={styles.iconBox}>
        <Ionicons name="camera" size={26} color="#A855F7" />
      </View>
      <View style={styles.info}>
        <Text style={styles.typeLabel}>Photo</Text>
        <Text style={styles.hint}>
          {isMine ? 'View once · sent' : 'Tap to open · view once'}
        </Text>
      </View>
      {!isMine && <Ionicons name="eye-outline" size={18} color="#A855F7" />}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 18,
    gap: 10,
    maxWidth: 240,
    marginVertical: 3,
  },
  sent: {
    backgroundColor: 'rgba(139,92,246,0.3)',
    borderWidth: 1,
    borderColor: 'rgba(196,181,255,0.25)',
    borderBottomRightRadius: 4,
    alignSelf: 'flex-end',
  },
  received: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    borderBottomLeftRadius: 4,
    alignSelf: 'flex-start',
  },
  expired:     { opacity: 0.45 },
  expiredText: { color: 'rgba(200,160,255,0.5)', fontSize: 13 },
  loadingText: { color: '#C4B5D8', fontSize: 13 },
  iconBox: {
    width: 46,
    height: 46,
    borderRadius: 12,
    backgroundColor: 'rgba(123,47,190,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  info:      { flex: 1 },
  typeLabel: { color: '#F3E8FF', fontSize: 14, fontWeight: '600' },
  hint:      { color: '#C4B5D8', fontSize: 11, marginTop: 2 },
  viewingWrapper: {
    position: 'relative',
    alignSelf: 'flex-start',
    marginVertical: 3,
  },
  media: { width: 260, height: 340, borderRadius: 16 },
  countdownBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(0,0,0,0.65)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  countdownText: { color: '#fff', fontSize: 12, fontWeight: '700' },
});
