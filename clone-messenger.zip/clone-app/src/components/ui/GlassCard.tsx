// src/components/ui/GlassCard.tsx
import React from 'react';
import { View, ViewStyle, StyleSheet } from 'react-native';
import { BlurView } from 'expo-blur';
import { useTheme } from '../../hooks/useTheme';

interface GlassCardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  intensity?: number;
  elevated?: boolean;
}

export function GlassCard({ children, style, intensity = 30, elevated = false }: GlassCardProps) {
  const { theme } = useTheme();

  return (
    <BlurView
      intensity={intensity}
      tint="dark"
      style={[
        styles.card,
        elevated && styles.elevated,
        { borderColor: `${theme.glow}40` },
        style,
      ]}
    >
      <View style={styles.inner}>{children}</View>
    </BlurView>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 20,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: 'rgba(123, 47, 190, 0.12)',
  },
  elevated: {
    shadowColor: '#7B2FBE',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 12,
  },
  inner: { flex: 1 },
});
