// src/components/ui/Avatar.tsx
import React from 'react';
import { View, Image, Text, StyleSheet, ViewStyle } from 'react-native';
import { useTheme } from '../../hooks/useTheme';

interface AvatarProps {
  uri?: string;
  name?: string;
  size?: number;
  showOnline?: boolean;
  style?: ViewStyle;
}

export function Avatar({ uri, name, size = 44, showOnline, style }: AvatarProps) {
  const { theme } = useTheme();
  const initials = name
    ? name.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase()
    : '?';

  return (
    <View style={[{ width: size, height: size }, style]}>
      <View style={[
        styles.ring,
        { width: size, height: size, borderRadius: size / 2, borderColor: `${theme.glow}80` },
      ]}>
        {uri ? (
          <Image
            source={{ uri }}
            style={{ width: size - 4, height: size - 4, borderRadius: (size - 4) / 2 }}
          />
        ) : (
          <View style={[
            styles.initials,
            { width: size - 4, height: size - 4, borderRadius: (size - 4) / 2,
              backgroundColor: `${theme.primary}55` },
          ]}>
            <Text style={[styles.initialsText, { fontSize: size * 0.33 }]}>{initials}</Text>
          </View>
        )}
      </View>
      {showOnline && (
        <View style={[styles.onlineDot, { bottom: 1, right: 1 }]} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  ring:         { borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  initials:     { alignItems: 'center', justifyContent: 'center' },
  initialsText: { color: '#F3E8FF', fontWeight: '700' },
  onlineDot: {
    position: 'absolute',
    width: 11,
    height: 11,
    borderRadius: 6,
    backgroundColor: '#34D399',
    borderWidth: 2,
    borderColor: '#0D0118',
  },
});
