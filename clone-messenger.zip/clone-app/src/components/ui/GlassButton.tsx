// src/components/ui/GlassButton.tsx
import React from 'react';
import {
  Pressable, Text, StyleSheet, ViewStyle, TextStyle, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme } from '../../hooks/useTheme';

interface GlassButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'ghost' | 'danger';
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  icon?: React.ReactNode;
}

export function GlassButton({
  label, onPress, variant = 'primary', loading, disabled, style, textStyle, icon,
}: GlassButtonProps) {
  const { theme } = useTheme();

  if (variant === 'primary') {
    return (
      <Pressable
        onPress={onPress}
        disabled={disabled || loading}
        style={({ pressed }) => [styles.base, { opacity: pressed ? 0.8 : 1 }, style]}
      >
        <LinearGradient
          colors={[theme.primaryLight, theme.primary, theme.primaryDark]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.gradient}
        >
          {loading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              {icon}
              <Text style={[styles.labelPrimary, textStyle]}>{label}</Text>
            </>
          )}
        </LinearGradient>
      </Pressable>
    );
  }

  if (variant === 'ghost') {
    return (
      <Pressable
        onPress={onPress}
        disabled={disabled || loading}
        style={({ pressed }) => [
          styles.base,
          styles.ghost,
          { borderColor: `${theme.primary}55`, opacity: pressed ? 0.7 : 1 },
          style,
        ]}
      >
        {loading ? (
          <ActivityIndicator color={theme.primaryLight} size="small" />
        ) : (
          <>
            {icon}
            <Text style={[styles.labelGhost, { color: theme.primaryLight }, textStyle]}>{label}</Text>
          </>
        )}
      </Pressable>
    );
  }

  // Danger
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.base,
        styles.danger,
        { opacity: pressed ? 0.7 : 1 },
        style,
      ]}
    >
      <Text style={[styles.labelPrimary, textStyle]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    borderRadius: 14,
    overflow: 'hidden',
    minHeight: 52,
    justifyContent: 'center',
  },
  gradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  ghost: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(123,47,190,0.12)',
    borderWidth: 1,
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  danger: {
    backgroundColor: 'rgba(248, 113, 113, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(248, 113, 113, 0.4)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
  },
  labelPrimary: { color: '#fff', fontSize: 15, fontWeight: '600' },
  labelGhost:   { fontSize: 15, fontWeight: '600' },
});
