// src/components/ui/GlassInput.tsx
import React, { useState } from 'react';
import { View, TextInput, Text, Pressable, StyleSheet, TextInputProps } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../hooks/useTheme';

interface GlassInputProps extends TextInputProps {
  label?: string;
  error?: string;
  icon?: keyof typeof Ionicons.glyphMap;
  isPassword?: boolean;
}

export function GlassInput({ label, error, icon, isPassword, style, ...rest }: GlassInputProps) {
  const { theme } = useTheme();
  const [focused, setFocused] = useState(false);
  const [showPw, setShowPw] = useState(false);

  return (
    <View style={styles.wrapper}>
      {label && <Text style={styles.label}>{label}</Text>}
      <View style={[
        styles.container,
        focused && { borderColor: theme.primaryLight },
        error && styles.errorBorder,
      ]}>
        {icon && (
          <Ionicons name={icon} size={18} color={focused ? theme.primaryLight : '#7C6B8E'} style={styles.icon} />
        )}
        <TextInput
          {...rest}
          style={[styles.input, style]}
          placeholderTextColor="rgba(200,160,255,0.35)"
          secureTextEntry={isPassword && !showPw}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />
        {isPassword && (
          <Pressable onPress={() => setShowPw(!showPw)} style={styles.eyeBtn}>
            <Ionicons name={showPw ? 'eye-off-outline' : 'eye-outline'} size={18} color="#7C6B8E" />
          </Pressable>
        )}
      </View>
      {error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper:     { marginBottom: 16 },
  label:       { color: '#C4B5D8', fontSize: 13, fontWeight: '500', marginBottom: 6, marginLeft: 4 },
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(123,47,190,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(200,150,255,0.2)',
    borderRadius: 14,
    paddingHorizontal: 16,
    minHeight: 52,
  },
  icon:        { marginRight: 10 },
  input:       { flex: 1, color: '#F3E8FF', fontSize: 15 },
  eyeBtn:      { padding: 4 },
  errorBorder: { borderColor: '#F87171' },
  error:       { color: '#F87171', fontSize: 12, marginTop: 4, marginLeft: 4 },
});
