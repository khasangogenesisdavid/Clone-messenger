// app/main/contacts/index.tsx
import React, { useState, useEffect } from 'react';
import {
  View, Text, FlatList, Pressable, StyleSheet, TextInput, ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar } from '../../../src/components/ui/Avatar';
import { GlassButton } from '../../../src/components/ui/GlassButton';
import { discoverContactsOnClone, searchUsers } from '../../../src/services/contactsService';
import { getOrCreateChat } from '../../../src/services/chatService';
import { useAuth } from '../../../src/hooks/useAuth';
import { useTheme } from '../../../src/hooks/useTheme';
import type { User } from '../../../src/types';

export default function ContactsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { theme } = useTheme();
  const [suggested, setSuggested] = useState<User[]>([]);
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [search, setSearch] = useState('');
  const [syncing, setSyncing] = useState(false);
  const [searching, setSearching] = useState(false);

  const handleSync = async () => {
    if (!user) return;
    setSyncing(true);
    try {
      const found = await discoverContactsOnClone(user.id);
      setSuggested(found);
    } catch (e) {
      console.error(e);
    } finally {
      setSyncing(false);
    }
  };

  useEffect(() => {
    if (!search.trim()) { setSearchResults([]); return; }
    const t = setTimeout(async () => {
      if (!user) return;
      setSearching(true);
      try {
        const results = await searchUsers(search, user.id);
        setSearchResults(results);
      } finally {
        setSearching(false);
      }
    }, 300);
    return () => clearTimeout(t);
  }, [search, user]);

  const startChat = async (contact: User) => {
    if (!user) return;
    const chat = await getOrCreateChat(user.id, contact.id);
    router.push({
      pathname: '/main/chats/[chatId]',
      params: { chatId: chat.id, recipientName: contact.display_name, recipientId: contact.id },
    });
  };

  const displayList = search.trim() ? searchResults : suggested;

  const renderUser = ({ item }: { item: User }) => (
    <Pressable
      style={({ pressed }) => [styles.userRow, pressed && styles.userRowPressed]}
      onPress={() => startChat(item)}
    >
      <Avatar uri={item.avatar_url} name={item.display_name} size={48} showOnline={item.is_online} />
      <View style={styles.userInfo}>
        <Text style={styles.userName}>{item.display_name}</Text>
        <Text style={styles.userSub}>{item.email ?? item.phone ?? 'Clone user'}</Text>
      </View>
      <View style={[styles.messageIcon, { backgroundColor: `${theme.primary}22` }]}>
        <Ionicons name="chatbubble-outline" size={18} color={theme.primaryLight} />
      </View>
    </Pressable>
  );

  return (
    <View style={styles.container}>
      <View style={[StyleSheet.absoluteFill, styles.bg]} />

      {/* Header */}
      <BlurView intensity={40} tint="dark" style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <View style={styles.headerRow}>
          <Text style={styles.headerTitle}>Contacts</Text>
        </View>
        {/* Search */}
        <View style={styles.searchBar}>
          <Ionicons name="search-outline" size={16} color="#7C6B8E" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search by name or email…"
            placeholderTextColor="rgba(200,160,255,0.3)"
            value={search}
            onChangeText={setSearch}
          />
          {searching && <ActivityIndicator size="small" color="#A855F7" />}
        </View>
      </BlurView>

      <FlatList
        data={displayList}
        keyExtractor={(item) => item.id}
        renderItem={renderUser}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 100 }]}
        ListHeaderComponent={
          !search.trim() ? (
            <View style={styles.syncSection}>
              <View style={styles.syncCard}>
                <Ionicons name="people-outline" size={28} color="#A855F7" />
                <View style={styles.syncText}>
                  <Text style={styles.syncTitle}>Find friends on Clone</Text>
                  <Text style={styles.syncSub}>Sync contacts to see who's already here</Text>
                </View>
              </View>
              <GlassButton
                label={syncing ? 'Syncing…' : 'Sync Contacts'}
                onPress={handleSync}
                loading={syncing}
                icon={<Ionicons name="sync-outline" size={18} color="#fff" />}
              />
              {suggested.length > 0 && (
                <Text style={styles.sectionLabel}>{suggested.length} contacts found</Text>
              )}
            </View>
          ) : null
        }
        ListEmptyComponent={
          !syncing && !searching ? (
            <View style={styles.empty}>
              <Ionicons name="person-add-outline" size={44} color="#3D2060" />
              <Text style={styles.emptyText}>
                {search.trim() ? 'No users found' : 'Sync your contacts to find friends'}
              </Text>
            </View>
          ) : null
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1 },
  bg:           { backgroundColor: '#0D0118' },
  header:       { borderBottomWidth: 1, borderBottomColor: 'rgba(200,150,255,0.1)' },
  headerRow:    { paddingHorizontal: 20, paddingBottom: 12 },
  headerTitle:  { color: '#F3E8FF', fontSize: 26, fontWeight: '800' },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: 'rgba(123,47,190,0.12)',
    borderWidth: 1, borderColor: 'rgba(200,150,255,0.15)',
    borderRadius: 12, marginHorizontal: 16, marginBottom: 12,
    paddingHorizontal: 12, paddingVertical: 10,
  },
  searchInput:  { flex: 1, color: '#F3E8FF', fontSize: 14 },
  list:         { paddingTop: 8 },
  syncSection:  { padding: 16, gap: 14 },
  syncCard: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    backgroundColor: 'rgba(123,47,190,0.12)',
    borderWidth: 1, borderColor: 'rgba(200,150,255,0.15)',
    borderRadius: 16, padding: 16,
  },
  syncText:     { flex: 1 },
  syncTitle:    { color: '#F3E8FF', fontSize: 15, fontWeight: '600' },
  syncSub:      { color: '#7C6B8E', fontSize: 13, marginTop: 3 },
  sectionLabel: { color: '#7C6B8E', fontSize: 13, fontWeight: '500' },
  userRow: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    paddingHorizontal: 16, paddingVertical: 12,
  },
  userRowPressed: { backgroundColor: 'rgba(123,47,190,0.1)' },
  userInfo:     { flex: 1 },
  userName:     { color: '#F3E8FF', fontSize: 15, fontWeight: '600' },
  userSub:      { color: '#7C6B8E', fontSize: 12, marginTop: 2 },
  messageIcon:  { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  empty:        { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyText:    { color: '#7C6B8E', fontSize: 14 },
});
