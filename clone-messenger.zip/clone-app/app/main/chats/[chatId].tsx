// app/main/chats/[chatId].tsx
import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  View, FlatList, TextInput, Pressable, Text,
  StyleSheet, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar } from '../../../src/components/ui/Avatar';
import { MessageBubble } from '../../../src/components/chat/MessageBubble';
import { ViewOnceMedia } from '../../../src/components/chat/ViewOnceMedia';
import { useMessages } from '../../../src/hooks/useMessages';
import { useAuth } from '../../../src/hooks/useAuth';
import { useTheme } from '../../../src/hooks/useTheme';
import { supabase } from '../../../src/config/supabase';
import { getOrCreateChat } from '../../../src/services/chatService';
import type { Message, User } from '../../../src/types';

export default function ChatRoomScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { theme } = useTheme();
  const { chatId: paramChatId, recipientName, recipientId } = useLocalSearchParams<{
    chatId?: string; recipientName: string; recipientId: string;
  }>();

  const [chatId, setChatId] = useState(paramChatId ?? '');
  const [recipient, setRecipient] = useState<User | null>(null);
  const [inputText, setInputText] = useState('');
  const listRef = useRef<FlatList>(null);
  const { messages, loading, sendMessage } = useMessages(chatId);

  // Load recipient profile
  useEffect(() => {
    if (!recipientId) return;
    supabase.from('users').select('*').eq('id', recipientId).single()
      .then(({ data }) => setRecipient(data));
  }, [recipientId]);

  // Init chat if no chatId provided
  useEffect(() => {
    if (!paramChatId && user && recipientId) {
      getOrCreateChat(user.id, recipientId).then((chat) => setChatId(chat.id));
    }
  }, [paramChatId, user, recipientId]);

  const handleSend = useCallback(async () => {
    const text = inputText.trim();
    if (!text || !recipient?.public_key) return;
    setInputText('');
    await sendMessage(text, recipient.public_key);
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
  }, [inputText, recipient, sendMessage]);

  const renderMessage = useCallback(({ item }: { item: Message }) => {
    const isMine = item.sender_id === user?.id;
    if (item.type === 'view_once_image' || item.type === 'view_once_video') {
      return <ViewOnceMedia message={item} isMine={isMine} />;
    }
    return <MessageBubble message={item} isMine={isMine} />;
  }, [user?.id]);

  return (
    <View style={styles.container}>
      <View style={[StyleSheet.absoluteFill, styles.bg]} />

      {/* ── Header ── */}
      <BlurView intensity={50} tint="dark" style={[styles.header, { paddingTop: insets.top + 6 }]}>
        <View style={styles.headerInner}>
          <Pressable style={styles.backBtn} onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={22} color="#C4B5D8" />
          </Pressable>
          <Pressable style={styles.userInfo} onPress={() => {}}>
            <Avatar uri={recipient?.avatar_url} name={recipientName} size={38} showOnline={recipient?.is_online} />
            <View style={styles.nameBlock}>
              <Text style={styles.recipientName} numberOfLines={1}>{recipientName}</Text>
              <Text style={[styles.onlineStatus, { color: recipient?.is_online ? '#34D399' : '#7C6B8E' }]}>
                {recipient?.is_online ? 'online' : 'offline'}
              </Text>
            </View>
          </Pressable>
          <View style={styles.headerActions}>
            <Pressable style={styles.actionBtn}>
              <Ionicons name="videocam-outline" size={22} color={theme.primaryLight} />
            </Pressable>
            <Pressable style={styles.actionBtn}>
              <Ionicons name="call-outline" size={22} color={theme.primaryLight} />
            </Pressable>
          </View>
        </View>
      </BlurView>

      {/* ── Messages ── */}
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessage}
          contentContainerStyle={[styles.messageList, { paddingBottom: 100 + insets.bottom }]}
          onContentSizeChange={() => listRef.current?.scrollToEnd()}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            !loading ? (
              <View style={styles.emptyChat}>
                <View style={styles.lockIcon}>
                  <Ionicons name="lock-closed" size={22} color="#A855F7" />
                </View>
                <Text style={styles.encryptedNote}>Messages are end-to-end encrypted</Text>
                <Text style={styles.encryptedSub}>Say hello to {recipientName}!</Text>
              </View>
            ) : null
          }
        />

        {/* ── Input Bar ── */}
        <BlurView
          intensity={70}
          tint="dark"
          style={[styles.inputBar, { paddingBottom: insets.bottom + 10 }]}
        >
          {/* View-once button */}
          <Pressable
            style={[styles.mediaBtn, { backgroundColor: `${theme.primary}22` }]}
            onPress={() => { /* TODO: open image picker with view-once option */ }}
          >
            <Ionicons name="camera-outline" size={22} color={theme.primaryLight} />
          </Pressable>

          <View style={[styles.inputWrapper, { borderColor: `${theme.primary}44` }]}>
            <TextInput
              style={styles.textInput}
              value={inputText}
              onChangeText={setInputText}
              placeholder="Message…"
              placeholderTextColor="rgba(200,160,255,0.35)"
              multiline
              maxLength={4000}
              onSubmitEditing={handleSend}
            />
          </View>

          <Pressable
            style={[
              styles.sendBtn,
              { backgroundColor: inputText.trim() ? theme.primary : `${theme.primary}33` },
            ]}
            onPress={handleSend}
          >
            <Ionicons name="send" size={17} color={inputText.trim() ? '#fff' : '#7C6B8E'} />
          </Pressable>
        </BlurView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:   { flex: 1 },
  bg:          { backgroundColor: '#0D0118' },
  flex:        { flex: 1 },
  header:      { borderBottomWidth: 1, borderBottomColor: 'rgba(200,150,255,0.1)' },
  headerInner: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingBottom: 10, gap: 10 },
  backBtn:     { padding: 6 },
  userInfo:    { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  nameBlock:   { flex: 1 },
  recipientName: { color: '#F3E8FF', fontSize: 16, fontWeight: '600' },
  onlineStatus:  { fontSize: 12, marginTop: 1 },
  headerActions: { flexDirection: 'row', gap: 4 },
  actionBtn:   { padding: 8 },
  messageList: { paddingHorizontal: 14, paddingTop: 12 },
  emptyChat:   { alignItems: 'center', paddingTop: 80, gap: 10 },
  lockIcon: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: 'rgba(123,47,190,0.2)',
    alignItems: 'center', justifyContent: 'center', marginBottom: 4,
  },
  encryptedNote: { color: '#C4B5D8', fontSize: 14, fontWeight: '500' },
  encryptedSub:  { color: '#7C6B8E', fontSize: 13 },
  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end', gap: 8,
    paddingHorizontal: 12, paddingTop: 10,
    borderTopWidth: 1, borderTopColor: 'rgba(200,150,255,0.08)',
  },
  mediaBtn: { width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  inputWrapper: {
    flex: 1, flexDirection: 'row', alignItems: 'flex-end',
    backgroundColor: 'rgba(123,47,190,0.15)',
    borderWidth: 1, borderRadius: 22,
    paddingHorizontal: 16, paddingVertical: 10, maxHeight: 120,
  },
  textInput:   { flex: 1, color: '#F3E8FF', fontSize: 15, lineHeight: 20 },
  sendBtn: {
    width: 42, height: 42, borderRadius: 21,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#7B2FBE', shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.7, shadowRadius: 10, elevation: 8,
  },
});
