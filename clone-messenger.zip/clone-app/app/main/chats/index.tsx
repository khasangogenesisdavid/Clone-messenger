// app/main/chats/index.tsx
import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, Pressable, StyleSheet,
  ImageBackground, TextInput,
} from 'react-native';
import { useRouter } from 'expo-router';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { format } from 'date-fns';
import { Avatar } from '../../../src/components/ui/Avatar';
import { getUserChats } from '../../../src/services/chatService';
import { useAuth } from '../../../src/hooks/useAuth';
import { useTheme } from '../../../src/hooks/useTheme';
import { supabase } from '../../../src/config/supabase';
import type { Chat } from '../../../src/types';

export default function ChatsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { theme } = useTheme();
  const [chats, setChats] = useState<Chat[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadChats();

    // Real-time: refresh when any chat updates
    const channel = supabase
      .channel('chats-list')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chats' }, loadChats)
      .subscribe();

    return () => { channel.unsubscribe(); };
  }, [user]);

  const loadChats = async () => {
    if (!user) return;
    try {
      const data = await getUserChats(user.id);
      // Populate other_user for each chat
      const enriched = await Promise.all(
        data.map(async (chat) => {
          const otherId = chat.participant_ids.find((id) => id !== user.id);
          if (!otherId) return chat;
          const { data: otherUser } = await supabase
            .from('users')
            .select('id, display_name, avatar_url, is_online')
            .eq('id', otherId)
            .single();
          return { ...chat, other_user: otherUser };
        })
      );
      setChats(enriched);
    } finally {
      setLoading(false);
    }
  };

  const filtered = chats.filter((c) =>
    c.other_user?.display_name?.toLowerCase().includes(search.toLowerCase())
  );

  const renderChat = ({ item }: { item: Chat }) => {
    const name = item.other_user?.display_name ?? 'Unknown';
    const time = item.last_message_at
      ? format(new Date(item.last_message_at), 'HH:mm')
      : '';

    return (
      <Pressable
        style={({ pressed }) => [styles.chatRow, pressed && styles.chatRowPressed]}
        onPress={() => router.push({ pathname: '/main/chats/[chatId]', params: { chatId: item.id, recipientName: name, recipientId: item.other_user?.id } })}
      >
        <Avatar uri={item.other_user?.avatar_url} name={name} size={52} showOnline={item.other_user?.is_online} />
        <View style={styles.chatInfo}>
          <View style={styles.chatTop}>
            <Text style={styles.chatName} numberOfLines={1}>{name}</Text>
            <Text style={styles.chatTime}>{time}</Text>
          </View>
          <View style={styles.chatBottom}>
            <Text style={styles.chatPreview} numberOfLines={1}>
              {item.last_message_type === 'view_once_image' ? '📷 Photo · view once' : (item.last_message ?? 'Start chatting')}
            </Text>
            {(item.unread_count ?? 0) > 0 && (
              <View style={[styles.unreadBadge, { backgroundColor: theme.primary }]}>
                <Text style={styles.unreadText}>{item.unread_count}</Text>
              </View>
            )}
          </View>
        </View>
      </Pressable>
    );
  };

  return (
    <View style={styles.container}>
      {/* Background */}
      <View style={[StyleSheet.absoluteFill, styles.bg]} />

      {/* Header */}
      <BlurView intensity={40} tint="dark" style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <View style={styles.headerRow}>
          <Text style={styles.headerTitle}>Messages</Text>
          <Pressable
            style={[styles.newChatBtn, { backgroundColor: `${theme.primary}33` }]}
            onPress={() => router.push('/main/contacts')}
          >
            <Ionicons name="create-outline" size={22} color={theme.primaryLight} />
          </Pressable>
        </View>
        {/* Search bar */}
        <View style={styles.searchBar}>
          <Ionicons name="search-outline" size={16} color="#7C6B8E" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search conversations…"
            placeholderTextColor="rgba(200,160,255,0.3)"
            value={search}
            onChangeText={setSearch}
          />
        </View>
      </BlurView>

      {/* Chat list */}
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={renderChat}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 90 }]}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="chatbubbles-outline" size={52} color="#3D2060" />
            <Text style={styles.emptyTitle}>No conversations yet</Text>
            <Text style={styles.emptySub}>Tap the pencil icon to start a chat</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container:  { flex: 1 },
  bg:         { backgroundColor: '#0D0118' },
  header:     { borderBottomWidth: 1, borderBottomColor: 'rgba(200,150,255,0.1)' },
  headerRow:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 12 },
  headerTitle: { color: '#F3E8FF', fontSize: 26, fontWeight: '800' },
  newChatBtn: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: 'rgba(123,47,190,0.12)',
    borderWidth: 1, borderColor: 'rgba(200,150,255,0.15)',
    borderRadius: 12, marginHorizontal: 16, marginBottom: 12,
    paddingHorizontal: 12, paddingVertical: 10,
  },
  searchInput: { flex: 1, color: '#F3E8FF', fontSize: 14 },
  list:        { paddingTop: 8 },
  chatRow: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    paddingHorizontal: 16, paddingVertical: 12,
  },
  chatRowPressed: { backgroundColor: 'rgba(123,47,190,0.1)' },
  chatInfo:    { flex: 1 },
  chatTop:     { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  chatName:    { color: '#F3E8FF', fontSize: 15, fontWeight: '600', flex: 1 },
  chatTime:    { color: '#7C6B8E', fontSize: 12 },
  chatBottom:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  chatPreview: { color: '#7C6B8E', fontSize: 13, flex: 1 },
  unreadBadge: { minWidth: 20, height: 20, borderRadius: 10, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  unreadText:  { color: '#fff', fontSize: 11, fontWeight: '700' },
  empty:       { alignItems: 'center', paddingTop: 100, gap: 12 },
  emptyTitle:  { color: '#C4B5D8', fontSize: 18, fontWeight: '600' },
  emptySub:    { color: '#7C6B8E', fontSize: 14 },
});
