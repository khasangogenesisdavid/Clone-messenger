// app/main/settings/index.tsx
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, Switch, Alert,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Avatar } from '../../../src/components/ui/Avatar';
import { GlassCard } from '../../../src/components/ui/GlassCard';
import { GlassButton } from '../../../src/components/ui/GlassButton';
import { useAuth } from '../../../src/hooks/useAuth';
import { useTheme } from '../../../src/hooks/useTheme';
import { signOut } from '../../../src/services/authService';
import { THEME_PRESETS } from '../../../src/theme/colors';

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { theme, setTheme, resetTheme } = useTheme();
  const [notifications, setNotifications] = useState(true);
  const [readReceipts, setReadReceipts] = useState(true);
  const [signingOut, setSigningOut] = useState(false);

  const handleSignOut = async () => {
    Alert.alert('Sign out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign out', style: 'destructive', onPress: async () => {
          setSigningOut(true);
          try { await signOut(); } finally { setSigningOut(false); }
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <View style={[StyleSheet.absoluteFill, styles.bg]} />

      {/* Header */}
      <BlurView intensity={40} tint="dark" style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <Text style={styles.headerTitle}>Settings</Text>
      </BlurView>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 100 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile card */}
        <GlassCard style={styles.profileCard} intensity={35}>
          <View style={styles.profileInner}>
            <Avatar uri={user?.avatar_url} name={user?.display_name} size={64} />
            <View style={styles.profileText}>
              <Text style={styles.profileName}>{user?.display_name ?? 'Clone User'}</Text>
              <Text style={styles.profileSub}>{user?.email ?? user?.phone ?? ''}</Text>
            </View>
            <Pressable style={styles.editBtn}>
              <Ionicons name="pencil-outline" size={18} color="#A855F7" />
            </Pressable>
          </View>
        </GlassCard>

        {/* Theme picker */}
        <Text style={styles.sectionTitle}>App Theme</Text>
        <GlassCard style={styles.section} intensity={25}>
          <View style={styles.themeGrid}>
            {THEME_PRESETS.map((preset) => {
              const isActive = theme.primary === preset.theme.primary;
              return (
                <Pressable
                  key={preset.name}
                  style={[styles.themeChip, isActive && { borderColor: preset.theme.glow, borderWidth: 2 }]}
                  onPress={() => setTheme(preset.theme)}
                >
                  <View style={[styles.themeDot, { backgroundColor: preset.theme.primary }]} />
                  <View style={[styles.themeDot, { backgroundColor: preset.theme.primaryLight }]} />
                  <View style={[styles.themeDot, { backgroundColor: preset.theme.glow }]} />
                  <Text style={styles.themeLabel}>{preset.name}</Text>
                  {isActive && <Ionicons name="checkmark-circle" size={14} color={preset.theme.glow} />}
                </Pressable>
              );
            })}
          </View>
          <Pressable onPress={resetTheme} style={styles.resetTheme}>
            <Text style={styles.resetThemeText}>Reset to default purple</Text>
          </Pressable>
        </GlassCard>

        {/* Privacy & notifications */}
        <Text style={styles.sectionTitle}>Privacy</Text>
        <GlassCard style={styles.section} intensity={25}>
          <SettingsRow
            icon="notifications-outline"
            label="Push Notifications"
            right={<Switch value={notifications} onValueChange={setNotifications} trackColor={{ true: theme.primary }} />}
          />
          <View style={styles.divider} />
          <SettingsRow
            icon="checkmark-done-outline"
            label="Read Receipts"
            right={<Switch value={readReceipts} onValueChange={setReadReceipts} trackColor={{ true: theme.primary }} />}
          />
          <View style={styles.divider} />
          <SettingsRow icon="lock-closed-outline" label="End-to-End Encryption" right={
            <View style={styles.activeBadge}><Text style={styles.activeBadgeText}>Active</Text></View>
          } />
        </GlassCard>

        {/* About */}
        <Text style={styles.sectionTitle}>About</Text>
        <GlassCard style={styles.section} intensity={25}>
          <SettingsRow icon="information-circle-outline" label="Version" right={<Text style={styles.valueText}>1.0.0</Text>} />
          <View style={styles.divider} />
          <SettingsRow icon="shield-checkmark-outline" label="Privacy Policy" right={<Ionicons name="chevron-forward" size={16} color="#7C6B8E" />} />
          <View style={styles.divider} />
          <SettingsRow icon="document-text-outline" label="Terms of Service" right={<Ionicons name="chevron-forward" size={16} color="#7C6B8E" />} />
        </GlassCard>

        {/* Sign out */}
        <GlassButton
          label="Sign Out"
          onPress={handleSignOut}
          variant="danger"
          loading={signingOut}
          style={styles.signOutBtn}
          icon={<Ionicons name="log-out-outline" size={18} color="#F87171" />}
        />
      </ScrollView>
    </View>
  );
}

function SettingsRow({ icon, label, right }: { icon: any; label: string; right: React.ReactNode }) {
  return (
    <View style={settingStyles.row}>
      <View style={settingStyles.left}>
        <Ionicons name={icon} size={20} color="#A855F7" />
        <Text style={settingStyles.label}>{label}</Text>
      </View>
      {right}
    </View>
  );
}

const settingStyles = StyleSheet.create({
  row:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 14, paddingHorizontal: 16 },
  left:  { flexDirection: 'row', alignItems: 'center', gap: 12 },
  label: { color: '#F3E8FF', fontSize: 15 },
});

const styles = StyleSheet.create({
  container:    { flex: 1 },
  bg:           { backgroundColor: '#0D0118' },
  header:       { borderBottomWidth: 1, borderBottomColor: 'rgba(200,150,255,0.1)', paddingHorizontal: 20, paddingBottom: 14 },
  headerTitle:  { color: '#F3E8FF', fontSize: 26, fontWeight: '800' },
  scroll:       { padding: 16, gap: 8 },
  profileCard:  { marginBottom: 8 },
  profileInner: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16 },
  profileText:  { flex: 1 },
  profileName:  { color: '#F3E8FF', fontSize: 17, fontWeight: '700' },
  profileSub:   { color: '#7C6B8E', fontSize: 13, marginTop: 2 },
  editBtn:      { padding: 8 },
  sectionTitle: { color: '#7C6B8E', fontSize: 12, fontWeight: '600', letterSpacing: 0.8, textTransform: 'uppercase', marginTop: 16, marginBottom: 6, marginLeft: 4 },
  section:      { marginBottom: 4 },
  themeGrid:    { flexDirection: 'row', flexWrap: 'wrap', gap: 10, padding: 14 },
  themeChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1, borderColor: 'rgba(200,150,255,0.15)',
    borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8,
  },
  themeDot:       { width: 10, height: 10, borderRadius: 5 },
  themeLabel:     { color: '#C4B5D8', fontSize: 12 },
  resetTheme:     { alignItems: 'center', paddingBottom: 12 },
  resetThemeText: { color: '#7C6B8E', fontSize: 13 },
  divider:        { height: 1, backgroundColor: 'rgba(200,150,255,0.08)', marginHorizontal: 16 },
  activeBadge:    { backgroundColor: 'rgba(52,211,153,0.15)', borderWidth: 1, borderColor: 'rgba(52,211,153,0.3)', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 3 },
  activeBadgeText: { color: '#34D399', fontSize: 12, fontWeight: '600' },
  valueText:      { color: '#7C6B8E', fontSize: 14 },
  signOutBtn:     { marginTop: 24 },
});
