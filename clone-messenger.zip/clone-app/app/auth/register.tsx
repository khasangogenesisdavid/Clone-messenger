// app/auth/register.tsx
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { GlassCard } from '../../src/components/ui/GlassCard';
import { GlassInput } from '../../src/components/ui/GlassInput';
import { GlassButton } from '../../src/components/ui/GlassButton';
import { signUpWithEmail, sendPhoneOTP } from '../../src/services/authService';

export default function RegisterScreen() {
  const router = useRouter();
  const { mode } = useLocalSearchParams<{ mode?: string }>();
  const isPhoneMode = mode === 'phone';

  const [tab, setTab] = useState<'email' | 'phone'>(isPhoneMode ? 'phone' : 'email');

  // Email fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Phone fields
  const [phone, setPhone] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleEmailRegister = async () => {
    if (!name || !email || !password) { setError('Please fill all fields'); return; }
    if (password.length < 8) { setError('Password must be at least 8 characters'); return; }
    setLoading(true); setError('');
    try {
      await signUpWithEmail(email, password, name);
    } catch (e: any) {
      setError(e.message ?? 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const handlePhoneSend = async () => {
    if (!phone) { setError('Enter your phone number'); return; }
    setLoading(true); setError('');
    try {
      await sendPhoneOTP(phone);
      router.push({ pathname: '/auth/otp-verify', params: { phone } });
    } catch (e: any) {
      setError(e.message ?? 'Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient colors={['#0D0118', '#1A0533', '#0D0118']} style={styles.bg}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">

          {/* Back button */}
          <Pressable style={styles.back} onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={22} color="#C4B5D8" />
          </Pressable>

          <View style={styles.header}>
            <Text style={styles.title}>Create account</Text>
            <Text style={styles.sub}>Join Clone — your messages stay private.</Text>
          </View>

          {/* Tabs */}
          <View style={styles.tabs}>
            <Pressable
              style={[styles.tab, tab === 'email' && styles.tabActive]}
              onPress={() => setTab('email')}
            >
              <Ionicons name="mail-outline" size={16} color={tab === 'email' ? '#F3E8FF' : '#7C6B8E'} />
              <Text style={[styles.tabText, tab === 'email' && styles.tabTextActive]}>Email</Text>
            </Pressable>
            <Pressable
              style={[styles.tab, tab === 'phone' && styles.tabActive]}
              onPress={() => setTab('phone')}
            >
              <Ionicons name="phone-portrait-outline" size={16} color={tab === 'phone' ? '#F3E8FF' : '#7C6B8E'} />
              <Text style={[styles.tabText, tab === 'phone' && styles.tabTextActive]}>Phone</Text>
            </Pressable>
          </View>

          <GlassCard style={styles.card} intensity={40}>
            <View style={styles.form}>
              {error ? <Text style={styles.error}>{error}</Text> : null}

              {tab === 'email' ? (
                <>
                  <GlassInput label="Full Name" value={name} onChangeText={setName}
                    placeholder="Your name" icon="person-outline" />
                  <GlassInput label="Email" value={email} onChangeText={setEmail}
                    placeholder="you@example.com" keyboardType="email-address"
                    autoCapitalize="none" icon="mail-outline" />
                  <GlassInput label="Password" value={password} onChangeText={setPassword}
                    placeholder="Min. 8 characters" isPassword icon="lock-closed-outline" />
                  <GlassButton label="Create Account" onPress={handleEmailRegister} loading={loading} />
                </>
              ) : (
                <>
                  <Text style={styles.phoneHint}>Enter your number with country code</Text>
                  <GlassInput label="Phone Number" value={phone} onChangeText={setPhone}
                    placeholder="+256 712 345 678" keyboardType="phone-pad" icon="call-outline" />
                  <GlassButton label="Send OTP" onPress={handlePhoneSend} loading={loading} />
                </>
              )}
            </View>
          </GlassCard>

          <View style={styles.footer}>
            <Text style={styles.footerText}>Already have an account? </Text>
            <Pressable onPress={() => router.push('/auth/login')}>
              <Text style={styles.linkText}>Sign in</Text>
            </Pressable>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  bg:       { flex: 1 },
  flex:     { flex: 1 },
  scroll:   { flexGrow: 1, padding: 24 },
  back:     { marginTop: 16, marginBottom: 8, width: 40, height: 40, justifyContent: 'center' },
  header:   { marginBottom: 24 },
  title:    { color: '#F3E8FF', fontSize: 28, fontWeight: '800', letterSpacing: -0.5 },
  sub:      { color: '#7C6B8E', fontSize: 14, marginTop: 6 },
  tabs: {
    flexDirection: 'row',
    backgroundColor: 'rgba(123,47,190,0.15)',
    borderRadius: 14,
    padding: 4,
    marginBottom: 20,
  },
  tab: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 10, borderRadius: 12,
  },
  tabActive:     { backgroundColor: 'rgba(123,47,190,0.45)' },
  tabText:       { color: '#7C6B8E', fontSize: 14, fontWeight: '500' },
  tabTextActive: { color: '#F3E8FF', fontWeight: '600' },
  card:          { borderRadius: 24 },
  form:          { padding: 24 },
  phoneHint:     { color: '#7C6B8E', fontSize: 13, marginBottom: 12 },
  error:         { color: '#F87171', fontSize: 13, marginBottom: 12, textAlign: 'center' },
  footer:        { flexDirection: 'row', justifyContent: 'center', marginTop: 24 },
  footerText:    { color: '#7C6B8E', fontSize: 14 },
  linkText:      { color: '#A855F7', fontSize: 14, fontWeight: '600' },
});
