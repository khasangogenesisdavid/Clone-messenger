// app/auth/login.tsx
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable,
  ImageBackground, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { GlassCard } from '../../src/components/ui/GlassCard';
import { GlassInput } from '../../src/components/ui/GlassInput';
import { GlassButton } from '../../src/components/ui/GlassButton';
import { signInWithEmail, signInWithGoogle } from '../../src/services/authService';

export default function LoginScreen() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleEmailLogin = async () => {
    if (!email || !password) { setError('Please fill in all fields'); return; }
    setLoading(true); setError('');
    try {
      await signInWithEmail(email, password);
      // Auth listener in _layout.tsx handles redirect
    } catch (e: any) {
      setError(e.message ?? 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true); setError('');
    try {
      await signInWithGoogle();
    } catch (e: any) {
      setError(e.message ?? 'Google sign-in failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient colors={['#0D0118', '#1A0533', '#0D0118']} style={styles.bg}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">

          {/* Logo area */}
          <View style={styles.logoArea}>
            <View style={styles.logoCircle}>
              <Text style={styles.logoText}>C</Text>
            </View>
            <Text style={styles.appName}>Clone</Text>
            <Text style={styles.tagline}>Private. Secure. Yours.</Text>
          </View>

          {/* Glass card form */}
          <GlassCard style={styles.card} intensity={40}>
            <View style={styles.form}>
              <Text style={styles.title}>Welcome back</Text>

              {error ? <Text style={styles.error}>{error}</Text> : null}

              <GlassInput
                label="Email"
                value={email}
                onChangeText={setEmail}
                placeholder="you@example.com"
                keyboardType="email-address"
                autoCapitalize="none"
                icon="mail-outline"
              />
              <GlassInput
                label="Password"
                value={password}
                onChangeText={setPassword}
                placeholder="••••••••"
                isPassword
                icon="lock-closed-outline"
              />

              <GlassButton label="Sign In" onPress={handleEmailLogin} loading={loading} />

              <View style={styles.divider}>
                <View style={styles.line} />
                <Text style={styles.orText}>or</Text>
                <View style={styles.line} />
              </View>

              {/* Google Sign In */}
              <Pressable style={styles.googleBtn} onPress={handleGoogleLogin}>
                <Ionicons name="logo-google" size={20} color="#fff" />
                <Text style={styles.googleText}>Continue with Google</Text>
              </Pressable>

              {/* Phone login */}
              <Pressable style={styles.phoneBtn} onPress={() => router.push('/auth/register?mode=phone')}>
                <Ionicons name="phone-portrait-outline" size={20} color="#A855F7" />
                <Text style={styles.phoneText}>Sign in with Phone</Text>
              </Pressable>
            </View>
          </GlassCard>

          {/* Register link */}
          <View style={styles.footer}>
            <Text style={styles.footerText}>Don't have an account? </Text>
            <Pressable onPress={() => router.push('/auth/register')}>
              <Text style={styles.linkText}>Sign up</Text>
            </Pressable>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  bg:      { flex: 1 },
  flex:    { flex: 1 },
  scroll:  { flexGrow: 1, justifyContent: 'center', padding: 24 },
  logoArea: { alignItems: 'center', marginBottom: 32 },
  logoCircle: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: 'rgba(123,47,190,0.4)',
    borderWidth: 2, borderColor: 'rgba(192,132,252,0.5)',
    alignItems: 'center', justifyContent: 'center', marginBottom: 12,
  },
  logoText:  { color: '#F3E8FF', fontSize: 36, fontWeight: '800' },
  appName:   { color: '#F3E8FF', fontSize: 28, fontWeight: '800', letterSpacing: -0.5 },
  tagline:   { color: '#7C6B8E', fontSize: 13, marginTop: 4 },
  card:      { borderRadius: 24 },
  form:      { padding: 24 },
  title:     { color: '#F3E8FF', fontSize: 22, fontWeight: '700', marginBottom: 20 },
  error:     { color: '#F87171', fontSize: 13, marginBottom: 12, textAlign: 'center' },
  divider:   { flexDirection: 'row', alignItems: 'center', marginVertical: 20, gap: 12 },
  line:      { flex: 1, height: 1, backgroundColor: 'rgba(200,150,255,0.15)' },
  orText:    { color: '#7C6B8E', fontSize: 13 },
  googleBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: '#4285F4', borderRadius: 14, paddingVertical: 14, marginBottom: 10,
  },
  googleText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  phoneBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: 'rgba(123,47,190,0.15)', borderWidth: 1,
    borderColor: 'rgba(168,85,247,0.3)', borderRadius: 14, paddingVertical: 14,
  },
  phoneText:   { color: '#A855F7', fontSize: 15, fontWeight: '600' },
  footer:      { flexDirection: 'row', justifyContent: 'center', marginTop: 24 },
  footerText:  { color: '#7C6B8E', fontSize: 14 },
  linkText:    { color: '#A855F7', fontSize: 14, fontWeight: '600' },
});
