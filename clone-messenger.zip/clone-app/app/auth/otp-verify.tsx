// app/auth/otp-verify.tsx
import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, TextInput, Pressable,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { GlassButton } from '../../src/components/ui/GlassButton';
import { verifyPhoneOTP, sendPhoneOTP } from '../../src/services/authService';

export default function OTPVerifyScreen() {
  const router = useRouter();
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const inputs = useRef<TextInput[]>([]);

  const handleDigit = (value: string, index: number) => {
    const newOtp = [...otp];
    newOtp[index] = value.replace(/\D/g, '').slice(-1);
    setOtp(newOtp);
    if (value && index < 5) inputs.current[index + 1]?.focus();
    if (!value && index > 0) inputs.current[index - 1]?.focus();
  };

  const handleVerify = async () => {
    const code = otp.join('');
    if (code.length < 6) { setError('Enter the full 6-digit code'); return; }
    setLoading(true); setError('');
    try {
      await verifyPhoneOTP(phone, code);
      // Auth listener handles redirect
    } catch (e: any) {
      setError(e.message ?? 'Invalid OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (resendCooldown > 0) return;
    try {
      await sendPhoneOTP(phone);
      setResendCooldown(60);
      const timer = setInterval(() => {
        setResendCooldown((c) => { if (c <= 1) { clearInterval(timer); return 0; } return c - 1; });
      }, 1000);
    } catch (e: any) {
      setError(e.message);
    }
  };

  return (
    <LinearGradient colors={['#0D0118', '#1A0533', '#0D0118']} style={styles.bg}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.container}>
          <Pressable style={styles.back} onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={22} color="#C4B5D8" />
          </Pressable>

          <View style={styles.iconWrap}>
            <Ionicons name="phone-portrait" size={40} color="#A855F7" />
          </View>

          <Text style={styles.title}>Verify your number</Text>
          <Text style={styles.sub}>
            We sent a 6-digit code to{'\n'}
            <Text style={styles.phone}>{phone}</Text>
          </Text>

          {/* OTP boxes */}
          <View style={styles.otpRow}>
            {otp.map((digit, i) => (
              <TextInput
                key={i}
                ref={(r) => { if (r) inputs.current[i] = r; }}
                style={[styles.otpBox, digit && styles.otpBoxFilled]}
                value={digit}
                onChangeText={(v) => handleDigit(v, i)}
                keyboardType="number-pad"
                maxLength={1}
                textAlign="center"
                selectionColor="#A855F7"
              />
            ))}
          </View>

          {error ? <Text style={styles.error}>{error}</Text> : null}

          <GlassButton label="Verify" onPress={handleVerify} loading={loading} style={styles.btn} />

          <Pressable onPress={handleResend} disabled={resendCooldown > 0} style={styles.resend}>
            <Text style={[styles.resendText, resendCooldown > 0 && styles.resendDisabled]}>
              {resendCooldown > 0 ? `Resend code in ${resendCooldown}s` : "Didn't get a code? Resend"}
            </Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  bg:         { flex: 1 },
  flex:       { flex: 1 },
  container:  { flex: 1, padding: 24, justifyContent: 'center' },
  back:       { position: 'absolute', top: 60, left: 24, width: 40, height: 40, justifyContent: 'center' },
  iconWrap: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: 'rgba(123,47,190,0.2)',
    borderWidth: 2, borderColor: 'rgba(168,85,247,0.35)',
    alignItems: 'center', justifyContent: 'center',
    alignSelf: 'center', marginBottom: 24,
  },
  title:   { color: '#F3E8FF', fontSize: 26, fontWeight: '800', textAlign: 'center' },
  sub:     { color: '#7C6B8E', fontSize: 14, textAlign: 'center', marginTop: 8, lineHeight: 22 },
  phone:   { color: '#A855F7', fontWeight: '600' },
  otpRow:  { flexDirection: 'row', justifyContent: 'center', gap: 10, marginVertical: 32 },
  otpBox: {
    width: 48, height: 58, borderRadius: 14,
    backgroundColor: 'rgba(123,47,190,0.15)',
    borderWidth: 1, borderColor: 'rgba(200,150,255,0.2)',
    color: '#F3E8FF', fontSize: 24, fontWeight: '700',
  },
  otpBoxFilled: { borderColor: '#A855F7', backgroundColor: 'rgba(168,85,247,0.2)' },
  error:        { color: '#F87171', fontSize: 13, textAlign: 'center', marginBottom: 16 },
  btn:          { marginTop: 8 },
  resend:       { marginTop: 20, alignItems: 'center' },
  resendText:   { color: '#A855F7', fontSize: 14, fontWeight: '500' },
  resendDisabled: { color: '#7C6B8E' },
});
