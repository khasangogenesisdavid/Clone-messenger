# Clone Messenger — Setup Guide

A secure, glassmorphism messaging app built with React Native (Expo) + Supabase.

---

## ⚡ Quick Start (5 steps)

### Step 1 — Install Tools
Download and install these (all free):
- **Node.js**: https://nodejs.org  (pick "LTS" version)
- **VS Code**: https://code.visualstudio.com
- **Expo Go app**: Install on your phone from App Store or Play Store

### Step 2 — Set Up Supabase (your backend)
1. Go to https://supabase.com → Sign up free
2. Click **New Project** → give it a name → set a password → Create
3. Wait ~2 minutes for it to spin up
4. Go to **SQL Editor** → **New Query**
5. Copy everything from `supabase_schema.sql` → Paste → Click **Run**
6. Go to **Settings → API** and copy:
   - `Project URL`  (looks like: https://xxxx.supabase.co)
   - `anon public` key (long string starting with eyJ...)

### Step 3 — Add Your Supabase Keys
Open the file: `src/config/supabase.ts`

Replace these two lines:
```
const SUPABASE_URL = 'https://YOUR_PROJECT_ID.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR_ANON_KEY_HERE';
```
With your actual values from Step 2.

### Step 4 — Install & Run
Open VS Code → Open the `clone-app` folder → Open Terminal (Ctrl+`) and type:

```bash
npm install
npx expo start
```

A QR code will appear in the terminal.

### Step 5 — View on Your Phone
- Open **Expo Go** on your phone
- Scan the QR code
- The app loads on your phone! 🎉

---

## 📱 Building a Real .APK / .IPA

When you're ready to build an installable app file:

1. Create a free account at https://expo.dev
2. Install EAS CLI:
   ```bash
   npm install -g eas-cli
   eas login
   eas build:configure
   ```
3. Build for Android:
   ```bash
   eas build --platform android --profile preview
   ```
   This gives you a `.apk` file you can install directly on Android.

4. Build for iOS (requires Apple Developer account $99/yr):
   ```bash
   eas build --platform ios
   ```

---

## 🎨 Customising the Theme
- Open the app → Settings → pick any of the 6 colour themes
- Or add your own in `src/theme/colors.ts` under `THEME_PRESETS`

## 🔐 Adding Your App Icon
Replace these files with your own images:
- `assets/images/icon.png` — 1024×1024 pixels, no transparency
- `assets/images/splash.png` — 1284×2778 pixels, dark background
- `assets/images/adaptive-icon.png` — 1024×1024 for Android

---

## 📁 Project Structure
```
clone-app/
├── app/                    ← Screens
│   ├── _layout.tsx         ← Root (auth gate)
│   ├── auth/               ← Login, Register, OTP
│   └── main/               ← Chats, Contacts, Settings
├── src/
│   ├── components/         ← Reusable UI components
│   ├── services/           ← Supabase, crypto, contacts
│   ├── hooks/              ← useAuth, useMessages, useTheme
│   ├── stores/             ← Zustand state
│   └── theme/              ← Colors, glass styles, typography
├── supabase_schema.sql     ← Run this in Supabase SQL Editor
└── README.md               ← This file
```

---

## 🛡️ Security Features
- ✅ End-to-end encryption (libsodium X25519)
- ✅ Private keys stored only on device (never sent to server)
- ✅ View-once media (atomic server-side deletion)
- ✅ Phone number hashing (SHA-256) for contact discovery
- ✅ Row Level Security on all Supabase tables
- ✅ Encrypted media in private storage buckets

---

Built with ❤️ — Clone Messenger v1.0
